

#ifndef NGX_WIN32
#define NGX_WIN32  1
#endif

